# create_db.py
import os
from flask import Flask
from models import db, User, Kategori
from werkzeug.security import generate_password_hash

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///inventory.db'
app.config['SECRET_KEY'] = 'gizli_anahtar'
db.init_app(app)

def recreate_db():
    # Veritabanı dosyasını sil
    if os.path.exists('inventory.db'):
        os.remove('inventory.db')
        print("Mevcut veritabanı silindi.")

    # Veritabanını yeniden oluştur
    with app.app_context():
        db.create_all()
        print("Veritabanı yeniden oluşturuldu.")

        # İlk kullanıcıyı oluştur (varsayılan kullanıcı adı ve şifre)
        if User.query.count() == 0:
            default_user = User(username='admin')
            default_user.set_password('password')
            db.session.add(default_user)
            db.session.commit()
            print("Varsayılan kullanıcı oluşturuldu.")

        # Varsayılan kategorileri oluştur
        if Kategori.query.count() == 0:
            kategoriler = ['Elektronik', 'Gıda', 'Temizlik', 'Diğer']
            for kategori_ad in kategoriler:
                kategori = Kategori(ad=kategori_ad)
                db.session.add(kategori)
            db.session.commit()
            print("Varsayılan kategoriler oluşturuldu.")

if __name__ == '__main__':
    recreate_db()