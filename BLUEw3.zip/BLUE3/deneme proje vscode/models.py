# models.py
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime

db = SQLAlchemy()

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(120), nullable=False)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    def __repr__(self):
        return f'<User {self.username}>'

class Kategori(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    ad = db.Column(db.String(100), nullable=False)
    urunler = db.relationship('Urun', backref='kategori', lazy=True)

    def __repr__(self):
        return f'<Kategori {self.ad}>'

class Urun(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    ad = db.Column(db.String(100), nullable=False)
    barkod = db.Column(db.String(100), unique=True, nullable=True)
    adet = db.Column(db.Integer, default=0)
    fiyat = db.Column(db.Float, default=0.0)
    bildirim_esigi = db.Column(db.Integer, default=5)
    kategori_id = db.Column(db.Integer, db.ForeignKey('kategori.id'), nullable=False)

    def __repr__(self):
        return f'<Urun {self.ad}>'

    def kritiklik_rengi(self):
        if self.adet < self.bildirim_esigi:
            oran = (self.adet / self.bildirim_esigi)
            kirmizi = int((1 - oran) * 255)
            yesil = int(oran * 255)
            return f'rgba({kirmizi}, {yesil}, 0, 0.7)'
        return 'rgba(0, 255, 0, 0.7)'

class Log(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    tarih = db.Column(db.DateTime, default=datetime.utcnow)
    aciklama = db.Column(db.String(200), nullable=False)

    def __repr__(self):
        return f'<Log {self.tarih}>'