from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify
from flask_sqlalchemy import SQLAlchemy

import logging
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash
import threading
import time

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///depo.db'
app.config['SECRET_KEY'] = 'gizli_anahtar'
db = SQLAlchemy(app)

# Loglama ayarları
logging.basicConfig(filename='depo.log', level=logging.INFO, 
                    format='%(asctime)s - %(levelname)s - %(message)s')

# Kullanıcı modeli
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(120), nullable=False)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

# SQLAlchemy modeli
class Urun(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    ad = db.Column(db.String(100), nullable=False)
    barkod = db.Column(db.String(100), unique=True, nullable=True)
    adet = db.Column(db.Integer, default=0)
    fiyat = db.Column(db.Float, default=0.0)
    bildirim_esigi = db.Column(db.Integer, default=5)

    def __repr__(self):
        return f'<Urun {self.ad}>'

    def kritiklik_rengi(self):
        if self.adet < self.bildirim_esigi:
            oran = (self.adet / self.bildirim_esigi)
            kirmizi = int((1 - oran) * 255)
            yesil = int(oran * 255)
            return f'rgb({kirmizi}, {yesil}, 0)'
        return 'rgb(0, 255, 0)'

# Log modeli
class Log(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    tarih = db.Column(db.DateTime, default=datetime.utcnow)
    islem = db.Column(db.String(200), nullable=False)

# Veritabanını oluştur
with app.app_context():
    db.create_all()
    # İlk kullanıcıyı oluştur (varsayılan kullanıcı adı ve şifre)
    if User.query.count() == 0:
        default_user = User(username='admin')
        default_user.set_password('password')
        db.session.add(default_user)
        db.session.commit()

# Anlık log bildirimleri için liste
anlik_loglar = []

# Log ekleme fonksiyonu
def log_ekle(islem, renk='info'):
    with app.app_context():
        log = Log(islem=islem)
        db.session.add(log)
        db.session.commit()
        
        # Anlık logları temizle ve yeni logu ekle
        global anlik_loglar
        anlik_loglar = [{'mesaj': islem, 'renk': renk}]
        
        time.sleep(3)  # 3 saniye bekle
        if anlik_loglar and anlik_loglar[0]['mesaj'] == islem:
            anlik_loglar.pop(0)

# Ana sayfa: Ürün listesi
@app.route('/')
def index():
    urunler = Urun.query.all()
    bildirim_sayisi = len([urun for urun in urunler if urun.adet < urun.bildirim_esigi])

    # Arama
    search = request.args.get('search')
    if search:
        urunler = [urun for urun in urunler if search.lower() in urun.ad.lower() or search in urun.barkod]

    # Sıralama
    sort_by = request.args.get('sort_by')
    if sort_by == 'ad':
        urunler = sorted(urunler, key=lambda urun: urun.ad)
    elif sort_by == 'fiyat':
        urunler = sorted(urunler, key=lambda urun: urun.fiyat)
    elif sort_by == 'adet':
        urunler = sorted(urunler, key=lambda urun: urun.adet)

    # Filtreleme
    filter_adet = request.args.get('filter_adet')
    if filter_adet:
        urunler = [urun for urun in urunler if urun.adet <= int(filter_adet)]

    return render_template('index.html', urunler=urunler, bildirim_sayisi=bildirim_sayisi, search=search, anlik_loglar=anlik_loglar)

# Ürün ekleme
@app.route('/urun_ekle', methods=['GET', 'POST'])
def urun_ekle():
    if request.method == 'POST':
        ad = request.form['ad']
        barkod = request.form['barkod']
        adet = int(request.form['adet'])
        fiyat = float(request.form['fiyat'])
        bildirim_esigi = int(request.form['bildirim_esigi'])

        yeni_urun = Urun(ad=ad, barkod=barkod, adet=adet, fiyat=fiyat, bildirim_esigi=bildirim_esigi)
        db.session.add(yeni_urun)
        db.session.commit()
        flash('Ürün başarıyla eklendi!', 'success')
        log_mesaji = f'Ürün eklendi: {ad} (Barkod: {barkod}, Adet: {adet}, Fiyat: {fiyat})'
        threading.Thread(target=log_ekle, args=(log_mesaji, 'success')).start()
        return redirect(url_for('index'))
    return render_template('urun_ekle.html')

@app.route('/urun_duzenle/<int:id>', methods=['GET', 'POST'])
def urun_duzenle(id):
    urun = Urun.query.get_or_404(id)
    
    if request.method == 'POST':
        if 'satis_adedi' in request.form:
            # Satılacak adet işleme
            satis_adedi = int(request.form['satis_adedi'])
            if urun.adet >= satis_adedi:
                urun.adet -= satis_adedi
                db.session.commit()
                flash('Satış başarıyla gerçekleşti!', 'success')
                log_mesaji = f'Ürün satıldı: {urun.ad} (ID: {id}, Adet: {satis_adedi}, Kalan Adet: {urun.adet})'
                threading.Thread(target=log_ekle, args=(log_mesaji, 'danger')).start()
            else:
                flash('Yeterli ürün yok!', 'danger')
        else:
            # Ürün düzenleme işlemi
            urun.ad = request.form['ad']
            urun.barkod = request.form['barkod']
            urun.adet = int(request.form['adet'])
            urun.fiyat = float(request.form['fiyat'])
            urun.bildirim_esigi = int(request.form['bildirim_esigi'])

            db.session.commit()
            flash('Ürün başarıyla güncellendi!', 'success')
            log_mesaji = f'Ürün güncellendi: {urun.ad} (ID: {id}, Adet: {urun.adet}, Fiyat: {urun.fiyat})'
            threading.Thread(target=log_ekle, args=(log_mesaji, 'info')).start()
        
        return redirect(url_for('urun_duzenle', id=id))
    
    return render_template('urun_duzenle.html', urun=urun)

# Ürün silme (sat)

@app.route('/urun_sil/<int:id>', methods=['POST'])
def urun_sil(id):
    urun = Urun.query.get(id)
    if urun:
        db.session.delete(urun)
        db.session.commit()
        flash('Ürün başarıyla silindi!', 'success')
        log_mesaji = f'Ürün silindi: {urun.ad} (ID: {id})'
        threading.Thread(target=log_ekle, args=(log_mesaji, 'danger')).start()
    else:
        flash('Ürün bulunamadı!', 'danger')
    return redirect(url_for('index'))  # 'urun_listesi' yerine 'index' sayfasına yönlendiriyoruz


@app.route('/urun_sat/<int:id>', methods=['POST'])
def urun_sat(id):
    urun = Urun.query.get_or_404(id)
    satis_adedi = int(request.form['satis_adedi'])
    if urun.adet >= satis_adedi:
        urun.adet -= satis_adedi
        db.session.commit()
        flash('Satış başarıyla gerçekleşti!', 'success')
        log_mesaji = f'Ürün satıldı: {urun.ad} (ID: {id}, Adet: {satis_adedi}, Kalan Adet: {urun.adet})'
        threading.Thread(target=log_ekle, args=(log_mesaji, 'danger')).start()
    else:
        flash('Yeterli ürün yok!', 'danger')
    return redirect(url_for('index'))

# Bildirimler
@app.route('/bildirimler')
def bildirimler():
    urunler = Urun.query.all()
    bildirimler = [urun for urun in urunler if urun.adet < urun.bildirim_esigi]
    return render_template('bildirimler.html', bildirimler=bildirimler)

@app.route('/barkod_sistemi', methods=['GET', 'POST'])
def barkod_sistemi():
    urun = None
    if request.method == 'POST':
        barkod = request.form['barkod']
        urun = Urun.query.filter_by(barkod=barkod).first()
        if not urun:
            flash('Ürün bulunamadı!', 'danger')
    return render_template('barkod_sistemi.html', urun=urun)


# Loglar
@app.route('/loglar', methods=['GET', 'POST'])
def loglar():
    if 'username' not in session:
        return redirect(url_for('login'))

    # Logları veritabanından çek
    loglar = Log.query.order_by(Log.tarih.desc()).all()

    # Arama
    search = request.args.get('search')
    if search:
        loglar = [log for log in loglar if search.lower() in log.islem.lower()]

    return render_template('loglar.html', loglar=loglar, search=search)

# Login
@app.route('/login', methods=['GET', 'POST'])
def login():
    # Login sayfasına girildiğinde anlık logları temizle
    global anlik_loglar
    anlik_loglar = []

    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username).first()

        if user and user.check_password(password):
            session['username'] = username
            flash('Giriş başarılı!', 'success')
            return redirect(url_for('loglar'))
        else:
            flash('Kullanıcı adı veya şifre hatalı!', 'danger')
    return render_template('login.html')

# Logout
@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('index'))

# Şifre değiştirme
@app.route('/sifre_degistir', methods=['GET', 'POST'])
def sifre_degistir():
    if 'username' not in session:
        return redirect(url_for('login'))

    if request.method == 'POST':
        eski_sifre = request.form['eski_sifre']
        yeni_sifre = request.form['yeni_sifre']

        user = User.query.filter_by(username=session['username']).first()

        if user and user.check_password(eski_sifre):
            user.set_password(yeni_sifre)
            db.session.commit()
            flash('Şifre başarıyla değiştirildi!', 'success')
            return redirect(url_for('loglar'))
        else:
            flash('Eski şifre hatalı!', 'danger')

    return render_template('sifre_degistir.html')

# Barkod oluşturma
@app.route('/barkod_olustur/<string:barkod>')
def barkod_olustur(barkod):
    EAN = barcode.get_barcode_class('ean13')
    ean = EAN(barkod, writer=ImageWriter())
    dosya_adi = f'barkod_{barkod}'
    ean.save(dosya_adi)
    return f"{dosya_adi}.png"

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)